include("includes/gloader.lua")

gloader.Load("XCF", "xcf")