DEFINE_BASECLASS("base_wire_entity") -- Use wiremod's base entity for easy wiremod integration

ENT.PrintName      = "XCF base scalable entity"
ENT.WireDebugName  = "XCF base scalable entity"

ENT.Spawnable = true
ENT.Category = "Other"
ENT.Author = "XCF Team"