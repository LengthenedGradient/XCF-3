DEFINE_BASECLASS("base_wire_entity") -- Use wiremod's base entity for easy wiremod integration

include("shared.lua") -- Includes and runs shared file on the client