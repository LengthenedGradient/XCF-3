-- shared.lua --
DEFINE_BASECLASS("xcf_base_scalable")

ENT.PrintName      = "XCF scalable test entity"
ENT.WireDebugName  = "XCF scalable test entity"
ENT.Spawnable = true
ENT.Category = "Other"
ENT.Author = "XCF Team"