-- cl_init.lua --

include("shared.lua") -- This runs shared.lua on the client